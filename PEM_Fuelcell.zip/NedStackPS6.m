%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%%       Dr.Tummala.S.L.V.Ayyarao
%% https://scholar.google.co.in/citations?user=X7i25FAAAAAJ&hl=en&oi=sra
%% GMR Institute of Technology, India
%%  Parameter extraction of PEM FC
%% If you use the code, cite the below paper
%% Ayyarao, Tummala SLV, Nishanth Polumahanthi, and Baseem Khan. "An accurate parameter estimation of PEM fuel cell using war strategy optimization." Energy 290 (2024): 130235.
%% Parameters of the NedStackPS6 PEM fuel cell stack
close all
clear  
clc
format long;
warning('off','all')
warning
%% Initialization
SearchAgents_no=50; % Number of search agents
global i Vs V_sa

Max_iteration=1000; % Maximum numbef of iterations

fobj=@Fuel_cell_NedStackPS6;% Objective function

lb=[-1.19969 0.001 3.6e-5 -2.6e-4 10 0.0136 1e-4]; % Lower bounds
ub=[-0.8532 0.005 9.8e-5 -9.54e-5 24 0.5 8e-4]; %Upper bound
dim=7; %Problem size
BEst=zeros(1,1);
BEst1=inf;
for k=1:1
    k
    
[Best_score,Best_pos,WSO_cg_curve]=WSO(SearchAgents_no,Max_iteration,lb,ub,dim,fobj);

end


Fuel_cell_NedStackPS6(Best_pos)
figure(1)
semilogy(WSO_cg_curve,'Color','b')
title('Objective space')
xlabel('Iteration');
ylabel('Best score obtained so far');
axis tight
grid on
box on
figure(2)
plot(i,V_sa)
hold on
plot(i,Vs,'d')
xlabel('Stack Current in A')
ylabel('Stack Voltage in V')