%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%               Dr.Tummala.S.L.V.Ayyarao
%% https://scholar.google.co.in/citations?user=X7i25FAAAAAJ&hl=en&oi=sra
%% GMR Institute of Technology, India
%%  Parameter extraction of PEM FC
%% If you use the code, cite the below paper
%% Ayyarao, Tummala SLV, Nishanth Polumahanthi, and Baseem Khan. "An accurate parameter estimation of PEM fuel cell using war strategy optimization." Energy 290 (2024): 130235.
function JJ = Fuel_cell_NedStackPS6(X)
global i Vs V_sa
zeta1 = X(1);
zeta2 = X(2);
zeta3 = X(3);
zeta4 = X(4);
Lemda =X(5);
b = X(6);
RC = X(7);
l = 0.0178;

T = 343; % Temperature (K)
Tc = T - 273.15; % Temperature (degrees C)
P_C = 1; % Hydrogen pressure in atm
P_A = 1; % Air pressure in atm
JJ = 0; % Initial Objective function value
j= 1;

il = 5; % Limiting current density (A/cm2)
A = 240; % Electrode specifi c interfacial area (1/cm)
%% Experimental Current and voltage data
i=[2.25,6.75,9,15.75,20.25,24.75,31.5,36,45,51.75,67.5,72,90,99,105.8,110.3,117,126,135,141.8,150.8,162,171,182.3,189,195.8,204.8,211.5,220.5];
V_sa=[61.64,59.57,58.94,57.54,56.8,56.13,55.23,54.66,53.61,52.86,51.91,51.22,49.66,49,48.15,47.52,47.1,46.48,45.66,44.85,44.24,42.45,41.66,40.68,40.09,39.51,38.73,38.15,37.38];
Nmax=max(size(i));
% i = i*A;
% Calculation of Partial Pressures
% Calculations of saturation pressure of water
for ii=1:Nmax
%     i
x = -2.18 + 0.0295 .* Tc-9.18 .* (10.^-5) .* (Tc.^2) + 1.44 .* (10.^-7) .* (Tc.^3); %eq 6
P_H2O = (10.^x);
% Calculation of partial pressure of hydrogen
% pp_H2 = 0.5 .*((P_A)./(exp(1.635 .* i(ii)./(1*T.^1.334)))-P_H2O); %eq 4
pp_H2 = 1;
% Calculation of partial pressure of oxygen
% pp_O2 = (P_C./exp(4.192 .* i/(1*T.^1.334)))-P_H2O;        %eq 5
pp_O2 = 1;
C_O2 = pp_O2/(5.08*10^6*exp(-498/T));                     % eq 8
V_act = -(zeta1+zeta2.*T+zeta3.*T.*log(C_O2)+zeta4.*T.*log(i(ii))); %eq 7
Rho_m = 181.6*(0.062*(T/303).^2*(i(ii)/A)^2.5+0.03*i(ii)/A+1)/((Lemda-0.634-3*i(ii)/A)*exp(4.18*(T-303)/T)); %eq 11
R_M = Rho_m*l/A;   %eq 10
V_ohmic =i(ii)*(R_M+RC); %eq 14
E_ern = 1.229-8.5*10^(-4)*(T-298.15)+4.3085*10^(-5)*T*(log(pp_H2)+0.5*log(pp_O2));  %eq (3)
V_con = -b*log(1-i(ii)/(A*il)); %eq 17
V_cell = E_ern-V_act-V_ohmic-V_con;
V_s = 65*V_cell;
% V_sa
% I(j)=i;
Vs(ii)=V_s;
% V_sA(ii)=V_sa(ii);
JJ= JJ+(V_s-V_sa(ii))^2;
% j=j+1;

end
end
